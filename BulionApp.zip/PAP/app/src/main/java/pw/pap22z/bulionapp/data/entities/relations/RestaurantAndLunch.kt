package pw.pap22z.bulionapp.data.entities.relations

//import androidx.room.Embedded
//import androidx.room.Relation
//import pw.pap22z.bulionapp.data.entities.Lunch
//import pw.pap22z.bulionapp.data.entities.Restaurant
//
//data class RestaurantAndLunch(
//    @Embedded val restaurant: Restaurant,
//    @Relation(
//        parentColumn = "id",
//        entityColumn = "lunchOwnerId"
//    )
//    val lunch: Lunch
//)
