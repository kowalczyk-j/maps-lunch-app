package pw.pap22z.bulionapp.data.entities.relations

//data class RestaurantWithReviews(
//    @Embedded val restaurant: Restaurant,
//    @Relation(
//        parentColumn = "id",
//        entityColumn = "restaurant_id"
//    )
//    val reviews: List<Review>
//)
