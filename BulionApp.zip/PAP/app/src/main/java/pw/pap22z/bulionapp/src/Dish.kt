package pw.pap22z.bulionapp.src

class Dish constructor(val name: String, val price: Double, val isVegetarian: Boolean, val isVegan: Boolean) {
}