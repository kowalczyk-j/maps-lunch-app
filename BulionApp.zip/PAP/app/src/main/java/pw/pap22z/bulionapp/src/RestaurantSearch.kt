package pw.pap22z.bulionapp.src

data class RestaurantSearch(var titleImage: Int, var description: String)
