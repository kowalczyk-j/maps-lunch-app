package pw.pap22z.bulionapp.src

class Review constructor(var rating: Double, var reviewBody: String,
                         var user: User) {
}